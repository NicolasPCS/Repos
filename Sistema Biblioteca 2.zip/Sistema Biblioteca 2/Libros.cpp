/////////////////////////////////////////////////////////////////////////////////
// C�digo   	: Libros.cpp
// Autor		: Nicolas
// Fecha		: 03/06/2020
// Descripci�n	: Definicion de la clase libros
/////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include "Libros.h"
using namespace std;
/*
Libro::Libro() {
	codigo = 0;
	tituloLibro = "";
	genero = "";
	numPaginas = 0;
	idioma = "";
	autor = "";
	// Inicializamos valores a los atributos protegidos
	// de la clase Sector (NOTA: si los atributos fueran privados
	// no podrian ser accedidos desde la clase derivada)
	nombreSec = " ";
	numLibros = 0;
}*/
// Fin del archivo Libros.cpp

// Definicion del metodo virtual puro de la clase base Sector en la clase derivada
// Libros
/*void Libro::mostrarSector() {
	cout << "\t(S)Nombre del sector: " << nombreSec << endl;
	cout << "\t(S)Cantidad libros en sector: " << numLibros << endl;
}*/