#include <iostream>
using namespace std;

// PRIMER NIVEL
class Vehiculo {
public:
	//metodo virtual de Vehiculo
	virtual void abordar() { cout << "Sube al vehiculo"; }
	//metodo normal de vehiculo
	void arrancar() { cout << "Encender motor y liberar freno"; }
};

// SEGUNDO NIVEL
class VehiculoAereo : public Vehiculo {
	//Metodo virtual implementado
	void abordar() { cout << "Subir a vehiculo Aereo"; }
};

class VehiculoTerrestre : public Vehiculo {
	//Metodo virtual implementado
	void abordar() { cout << "Subir a vehiculo Terrestre"; }
};

class VehiculoAcuatico : public Vehiculo {
	//Metodo virtual implementado
	void abordar() { cout << "Subir a vehiculo Acuatico"; }
};

// TERCER NIVEL
class VehiculoTerrestreCarga : public VehiculoTerrestre {
	//Metodo virtual implementado
	void abordar() { cout << "Subir carga a vehiculo Terrestre Carga"; }
};

class VehiculoTerrestrePasajeros : public VehiculoTerrestre {
	//Metodo virtual implementado
	void abordar() { cout << "Subir pasajeros a vehiculo Terrestre y tomar asientos"; }
};

class VehiculoAcuaticoRecreo : public VehiculoAcuatico {
	//Metodo virtual implementado
	void abordar() { cout << "Subir pasajeros a vehiculo Acutico Recreacional y tomar asientos"; }
};

// CUARTO NIVEL

// Dos clases derivadas del tercer nivel, clase VehiculoTerrestreCarga
class Camion : public VehiculoTerrestreCarga {
	//Metodo virtual implementado
	void abordar() { cout << "Subir carga a camion"; }
};

class Volqueta : public VehiculoTerrestreCarga {
	//Metodo virtual implementado
	void abordar() { cout << "Subir carga a volqueta"; }
};

// Dos clases derivadas del tercer nivel, clase VehiculoTerrestrePasajeros
class Bus : public VehiculoTerrestrePasajeros {
	//Metodo virtual implementado
	void abordar() { cout << "Subir a bus y tomar asientos"; }
};

class Combi : public VehiculoTerrestrePasajeros {
	void abordar() { cout << "Subir a bus y tomar asientos"; }
};

// Dos clases derivadas del tercer nivel, clase VehiculoAcuaticoRecreo
class Yate : public VehiculoAcuaticoRecreo {
	//Metodo virtual implementado
	void abordar() { "Subir al yate y ponerse bloqueador"; }
};

class MotoAcuatica : public VehiculoAcuaticoRecreo {
	void abordar() { "Subir a la moto acuatica y ponerse bloqueador"; }
};

int main() {
	int num;
	cout << "Ingresar el numero de vehiculos"; cin >> num;
	Vehiculo** vehiculos = new Vehiculo*[num];
	for (int i = 0; i < num; i++) {
		vehiculos[i] = new VehiculoAereo(); break;
	}

	for (int i = 0; i < num; i++) {
		vehiculos[i]->arrancar(); break;
	}

	system("pause");
	return 0;
}